import { StyledButton } from './style';

const Button = () => {
  return <StyledButton>Button</StyledButton>;
};

export default Button;
