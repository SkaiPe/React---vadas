import { styled } from 'styled-components';

export const StyledButton = styled.button`
  padding: 0.3em 0.5em;
  border: none;
  outline: none;
  background-color: salmon;
  color: white;
`;
