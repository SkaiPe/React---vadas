import { styled } from 'styled-components';

export const StyledCardWrapper = styled.div``;

export const StyledCardHeaderContainer = styled.div``;

export const StyledCardHeader = styled.h5``;

export const StyledDivider = styled.div``;

export const StyledCardContentContainer = styled.div``;

export const StyledCardContentHeader = styled.h4``;

export const StyledCardContentParagraph = styled.p``;
